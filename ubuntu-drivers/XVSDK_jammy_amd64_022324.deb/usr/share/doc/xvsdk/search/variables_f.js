var searchData=
[
  ['s_642',['s',['../structxv_1_1DateTime.html#ac57cc204cca9713b63061c72bca99241',1,'xv::DateTime']]],
  ['setup_5fstatus_643',['setup_status',['../structxv_1_1CalibrationStatus.html#ad9317637961c4f254ba67e5f42f0cd1e',1,'xv::CalibrationStatus']]],
  ['signal_644',['signal',['../structxv_1_1GPSDistanceData.html#a8100391aceb306f8e5cf50dd0680c71b',1,'xv::GPSDistanceData']]],
  ['size_645',['size',['../structxv_1_1GazeCalibrationData.html#ae095bb343d20e347dc2efd3785bc627e',1,'xv::GazeCalibrationData']]],
  ['slamposition_646',['slamPosition',['../structxv_1_1GestureData.html#ac0922b31e2d55a80870ad7c94ef6cc5e',1,'xv::GestureData']]],
  ['smoothpoint_647',['smoothPoint',['../structxv_1_1XV__ET__GAZE__POINT.html#a99965d901a25c0b8d9ac388d4a81e107',1,'xv::XV_ET_GAZE_POINT']]],
  ['state_648',['state',['../structxv_1_1Event.html#ad3992cc0d623867a30ded9f2800b184e',1,'xv::Event']]],
  ['sum_649',['sum',['../structxv_1_1GPSDistanceData.html#a931a69125b80fda5eae230938f5f1830',1,'xv::GPSDistanceData']]]
];
