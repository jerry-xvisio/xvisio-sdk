var searchData=
[
  ['registercallback_513',['registerCallback',['../classxv_1_1Stream.html#a77065069930031e9c1397d8d2af11a4b',1,'xv::Stream']]],
  ['registercolordepthimagecallback_514',['registerColorDepthImageCallback',['../classxv_1_1TofCamera.html#a5ffb7904edee69e6894895e655a76f14',1,'xv::TofCamera']]],
  ['registerdynamicgesturecallback_515',['registerDynamicGestureCallback',['../classxv_1_1GestureStream.html#a0d98bdd3cc1f2189feb22e98dc7e4506',1,'xv::GestureStream']]],
  ['registerenrollcallback_516',['registerEnrollCallback',['../classxv_1_1IrisStream.html#ae5a41f7621022126ca01b8a4cc9b4b8e',1,'xv::IrisStream']]],
  ['registeridentifycallback_517',['registerIdentifyCallback',['../classxv_1_1IrisStream.html#afbb5005f1850bc7baaa74ca90022c40e',1,'xv::IrisStream']]],
  ['registerkeypointscallback_518',['registerKeypointsCallback',['../classxv_1_1GestureStream.html#a4a9949b899b67eb18d3ab3bcedcf678a',1,'xv::GestureStream']]],
  ['registerlostcallback_519',['registerLostCallback',['../classxv_1_1Slam.html#adcd3a606402c9b6e2efcef0319c8b93f',1,'xv::Slam']]],
  ['registermapcallback_520',['registerMapCallback',['../classxv_1_1Slam.html#a2e482f687e0970dfa1c9abad5278e485',1,'xv::Slam']]],
  ['registerplayendcallback_521',['registerPlayEndCallback',['../classxv_1_1Speaker.html#a350a747a843a649f62e53f8a4f9cdc30',1,'xv::Speaker']]],
  ['registerplugeventcallback_522',['registerPlugEventCallback',['../group__xv__functions.html#ga1635ffa7bca12160d4ccc9cbbc7987ef',1,'xv']]],
  ['registerslamkeypointscallback_523',['registerSlamKeypointsCallback',['../classxv_1_1GestureStream.html#a967e5b570692739562a3fcf60bc83309',1,'xv::GestureStream']]],
  ['registerstereoplanescallback_524',['registerStereoPlanesCallback',['../classxv_1_1Slam.html#a197e1046b163085cdf86c5e0d1d07c79',1,'xv::Slam']]],
  ['registertofplanescallback_525',['registerTofPlanesCallback',['../classxv_1_1Slam.html#a4d9b5d29be7e8f952ba3e6501ab817a2',1,'xv::Slam']]],
  ['registervisualposecallback_526',['registerVisualPoseCallback',['../classxv_1_1Slam.html#a913bd709a901eed15e48670a6cfe8fad',1,'xv::Slam']]],
  ['reset_527',['reset',['../classxv_1_1Slam.html#afe502b3d0fd50405a7528659124bce75',1,'xv::Slam']]],
  ['rgbimage_528',['RgbImage',['../structxv_1_1RgbImage.html#a600cb5486d8dc1d6bb09d3d8c7b41439',1,'xv::RgbImage']]],
  ['rotation_529',['rotation',['../classxv_1_1details_1_1Transform__.html#ade74f0f888c9c3727e737114d39689f4',1,'xv::details::Transform_::rotation()'],['../classxv_1_1Orientation.html#a2956c450561320ae98ae00c796da298f',1,'xv::Orientation::rotation()']]],
  ['rotationtopitchyawroll_530',['rotationToPitchYawRoll',['../group__xv__rotation__conversions.html#ga2e933d4631944d4ab6ff3d0aa0ce7223',1,'xv::rotationToPitchYawRoll(Matrix3d const &amp;rot)'],['../group__xv__rotation__conversions.html#gad1ab736f853d0e899de83452d916adb3',1,'xv::rotationToPitchYawRoll(Matrix3f const &amp;rot)']]],
  ['rotationtoquaternion_531',['rotationToQuaternion',['../group__xv__rotation__conversions.html#gaee4a8cad3cd0fd3ffa551bc85c6ab466',1,'xv::rotationToQuaternion(Matrix3f const &amp;rot)'],['../group__xv__rotation__conversions.html#ga65fcec2c0e1d5f7eb5180841d0845782',1,'xv::rotationToQuaternion(Matrix3d const &amp;rot)']]]
];
