var searchData=
[
  ['details_444',['details',['../namespacexv_1_1details.html',1,'xv']]]
];
