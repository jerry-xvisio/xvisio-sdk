var searchData=
[
  ['object_369',['Object',['../structxv_1_1Object.html',1,'xv']]],
  ['objectdescriptor_370',['ObjectDescriptor',['../structxv_1_1ObjectDescriptor.html',1,'xv']]],
  ['objectdetector_371',['ObjectDetector',['../classxv_1_1ObjectDetector.html',1,'xv']]],
  ['orientation_372',['Orientation',['../classxv_1_1Orientation.html',1,'xv']]],
  ['orientationstream_373',['OrientationStream',['../classxv_1_1OrientationStream.html',1,'xv']]]
];
