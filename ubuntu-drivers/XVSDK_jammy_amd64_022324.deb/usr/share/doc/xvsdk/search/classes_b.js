var searchData=
[
  ['rgbimage_389',['RgbImage',['../structxv_1_1RgbImage.html',1,'xv']]]
];
