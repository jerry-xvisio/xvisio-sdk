var searchData=
[
  ['version_20helper_2e_672',['Version helper.',['../group__Version.html',1,'']]]
];
