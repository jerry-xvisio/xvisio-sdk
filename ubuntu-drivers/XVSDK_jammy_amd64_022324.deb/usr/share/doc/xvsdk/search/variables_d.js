var searchData=
[
  ['patch_623',['patch',['../structxv_1_1Version.html#aa7e14daf6de6cbd6f0c77bf63da30877',1,'xv::Version']]],
  ['pdcm_624',['pdcm',['../structxv_1_1Calibration.html#a750e9d4701caa6c0e240c342b67698e8',1,'xv::Calibration']]],
  ['points_625',['points',['../structxv_1_1Plane.html#ae65f776acd4a32ddd65c8ae5c8d01832',1,'xv::Plane']]],
  ['position_626',['position',['../structxv_1_1GestureData.html#a7567617850b9010b2cd4c5fe10521c4a',1,'xv::GestureData']]],
  ['pupilbitmask_627',['pupilBitMask',['../structxv_1_1XV__ET__PUPIL__INFO.html#a1f1532475964707dfc044b0a2511ea61',1,'xv::XV_ET_PUPIL_INFO']]],
  ['pupilcenter_628',['pupilCenter',['../structxv_1_1XV__ET__PUPIL__INFO.html#a7da715548dcdd0d3b8bcb9fcce39c4c6',1,'xv::XV_ET_PUPIL_INFO']]],
  ['pupildiameter_629',['pupilDiameter',['../structxv_1_1XV__ET__PUPIL__INFO.html#a6fcf98838dba18deedd2f73b0047ca9d',1,'xv::XV_ET_PUPIL_INFO']]],
  ['pupildiametermm_630',['pupilDiameterMM',['../structxv_1_1XV__ET__PUPIL__INFO.html#ae9b9f56ae49e934b10d1fa6a4bcc39d0',1,'xv::XV_ET_PUPIL_INFO']]],
  ['pupildistance_631',['pupilDistance',['../structxv_1_1XV__ET__PUPIL__INFO.html#aa6c620d3ab9589a89dff498d0690f590',1,'xv::XV_ET_PUPIL_INFO']]],
  ['pupilminoraxis_632',['pupilMinorAxis',['../structxv_1_1XV__ET__PUPIL__INFO.html#aa1f4b131190d929d85216d033971a7ca',1,'xv::XV_ET_PUPIL_INFO']]],
  ['pupilminoraxismm_633',['pupilMinorAxisMM',['../structxv_1_1XV__ET__PUPIL__INFO.html#a5d52f8ad6af97bc646432c2077f89546',1,'xv::XV_ET_PUPIL_INFO']]]
];
